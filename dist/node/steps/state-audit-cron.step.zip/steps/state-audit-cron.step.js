"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// steps/state-audit-cron.step.ts
var state_audit_cron_step_exports = {};
__export(state_audit_cron_step_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(state_audit_cron_step_exports);
var config = {
  type: "cron",
  cron: "*/5 * * * *",
  // run every 5 minutes
  name: "StateAuditJob",
  description: "Checks the state for orders that are not complete and have a ship date in the past",
  emits: ["notification"],
  flows: ["basic-tutorial"]
};
var handler = async ({ logger, state, emit }) => {
  const stateValue = await state.getGroup("orders");
  for (const item of stateValue) {
    const currentDate = /* @__PURE__ */ new Date();
    const shipDate = new Date(item.shipDate);
    if (!item.complete && currentDate > shipDate) {
      logger.warn("Order is not complete and ship date is past", {
        orderId: item.id,
        shipDate: item.shipDate,
        complete: item.complete
      });
      await emit({
        topic: "notification",
        data: {
          email: "test@test.com",
          templateId: "order-audit-warning",
          templateData: {
            orderId: item.id,
            status: item.status,
            shipDate: item.shipDate,
            message: "Order is not complete and ship date is past"
          }
        }
      });
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
//# sourceMappingURL=state-audit-cron.step.js.map
